var app = angular.module('myApp', []);
app.constant('CONFIG', {
    'APP_NAME' : 'Green n Personal',
    'APP_VERSION' : '1.0.0',
    'GOOGLE_ANALYTICS_ID' : '',
    'BASE_URL' : 'http://localhost:8080/',
    'SYSTEM_LANGUAGE' : ''
})
app.filter('trusted', ['$sce', function ($sce) {
   return $sce.trustAsResourceUrl;
}]);
app.controller('homeCtrl', function($scope,$rootScope,$http,CONFIG,$location) {
    	

	$scope.login = {};
	$scope.signup = {};
	$scope.GethomepageData = function(){
	    $http({
	      method  : 'GET',
	      url     : CONFIG.BASE_URL+'api/frontend/category_mang',  
	    })
	    .success(function(data) {
	      //console.log(data);
	      if (data.errors) {

	      } else {
	      	$scope.items =  data.data;
	      }
	    });
	};
	$scope.GethomepageData();

	$scope.checkLogin = function(){
		$http({
	      method  : 'GET',
	      url     : CONFIG.BASE_URL 
	    })
	    .success(function(data) {
	      
	      if (data.response == 0) {
	      	alert(data.message)
	      } else {
	      	$scope.items =  data.data;
	      	
	      }
	    });
		event.stopPropagation()
	};
	$scope.checkLogin();
	$scope.doregister = function(frmObj){
		$http({
	      method  : 'POST',
	      url     : CONFIG.BASE_URL+'api/signup', 
	      data 	  : $scope.userData 
	    })
	    .success(function(data) {
	      console.log(data);
	      if (data.response == 0) {
	      	alert(data.message)
	      } else {
	      	$scope.items =  data.data;
	      }
	    });
		event.stopPropagation()
	};

	$scope.dologin = function(frmObj){
		$http({
	      method  : 'POST',
	      url     : CONFIG.BASE_URL+'api/login', 
	      data 	  : $scope.userData 
	    })
	    .success(function(data) {
	      
	      if (data.response == 0) {
	      	alert(data.message)
	      } else {
	      	$scope.items =  data.data;
	      	window.sessionStorage.setItem('user_data', JSON.stringify(data.data))
	      	//$scope.checkLogin();
	      }
	    });
		event.stopPropagation()
	};
});
app.controller('categoryCtrl', function($scope, $rootScope, $http, CONFIG,$location){
	var searchObject = $location.search();
	console.log(searchObject);
	$http({
      method  : 'GET',
      url     : CONFIG.BASE_URL+'api/frontend/category_mang?id='+searchObject.id,  
    })
    .success(function(data) {
      //console.log(data);
      if (data.errors) {

      } else {
      	$scope.items =  data.data;
      }
    });
});
app.controller('invitationCtrl', function($scope, $rootScope, $http, CONFIG,$location){
	var searchObject = $location.search();
	console.log(searchObject);
	$http({
      method  : 'GET',
      url     : CONFIG.BASE_URL+'api/frontend/invitation_card?id='+searchObject.id,  
    })
    .success(function(data) {
      //console.log(data);
      if (data.errors) {

      } else {
      	$scope.items =  data.data;
      }
    });
})

app.controller('formCtrl', function($scope, $rootScope, $http, CONFIG,$location){
	var searchObject = $location.search();
	
	$http({
      method  : 'GET',
      url     : CONFIG.BASE_URL+'api/frontend/form?id='+searchObject.card_id,  
    })
    .success(function(data) {
      if (data.errors) {

      } else {
      	window.sessionStorage.setItem('formData', JSON.stringify(data.data.data));
      	$scope.items =  data.data;
      }
    });
})